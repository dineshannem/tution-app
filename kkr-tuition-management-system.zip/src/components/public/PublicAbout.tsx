import React from 'react';
import { Award, BookOpen, Users, CheckCircle2, Heart } from 'lucide-react';

interface PublicAboutProps {
  openFreeDemo: () => void;
  openAdmission: () => void;
}

export const PublicAbout: React.FC<PublicAboutProps> = ({ openFreeDemo, openAdmission }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
      {/* Bio Header */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-5 relative">
          <div className="rounded-3xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 h-96">
            <img
              src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=800&auto=format&fit=crop&q=80"
              alt="KKR Sir"
              className="w-full h-full object-cover"
            />
          </div>
          <div className="absolute -bottom-6 -right-6 bg-amber-500 text-slate-950 p-4 rounded-2xl shadow-xl font-extrabold text-sm space-y-0.5">
            <div>K. K. Rao (KKR Sir)</div>
            <div className="text-xs text-slate-900 font-semibold">M.Sc Mathematics & Physics</div>
            <div className="text-[11px] text-slate-800">15+ Years Board Coaching</div>
          </div>
        </div>

        <div className="lg:col-span-7 space-y-5">
          <span className="text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-widest bg-amber-50 dark:bg-amber-950/60 px-3 py-1 rounded-full border border-amber-200 dark:border-amber-800/60">
            About KKR Tuition
          </span>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white leading-tight">
            Single-Teacher Dedication for Lasting Educational Excellence
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            Founded by K. K. Rao (KKR Sir), KKR Tuition was established with a singular mission: to eliminate the confusion caused by frequent teacher changes and large, impersonal coaching institutes.
          </p>
          <p className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
            As the sole teacher and academic director, KKR Sir personally conducts every batch for Classes 1 through 10. This ensures seamless continuity in teaching methodology, deep knowledge of every student's learning profile, and absolute accountability to parents.
          </p>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-2xl font-black text-amber-500">1,500+</div>
              <div className="text-xs text-slate-500">Students Guided</div>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
              <div className="text-2xl font-black text-blue-500">98.4%</div>
              <div className="text-xs text-slate-500">Board Distinction Score</div>
            </div>
          </div>
        </div>
      </div>

      {/* Core Principles */}
      <div className="space-y-8 bg-slate-900 text-white p-10 rounded-3xl">
        <div className="text-center space-y-2 max-w-2xl mx-auto">
          <h2 className="text-2xl font-bold">The KKR Tuition Pillars</h2>
          <p className="text-xs text-slate-400">Our core commitments to parents and students in Hyderabad.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-slate-300">
          <div className="bg-slate-800/70 p-6 rounded-2xl border border-slate-700 space-y-3">
            <Users className="w-8 h-8 text-amber-400" />
            <h3 className="text-base font-bold text-white">Small Batch Culture</h3>
            <p className="text-xs leading-relaxed">
              Strict limit of 15 students per batch ensuring every doubt is resolved live in class.
            </p>
          </div>

          <div className="bg-slate-800/70 p-6 rounded-2xl border border-slate-700 space-y-3">
            <BookOpen className="w-8 h-8 text-blue-400" />
            <h3 className="text-base font-bold text-white">Bilingual Explanation</h3>
            <p className="text-xs leading-relaxed">
              Complex mathematical proofs and scientific laws explained clearly in Telugu and English.
            </p>
          </div>

          <div className="bg-slate-800/70 p-6 rounded-2xl border border-slate-700 space-y-3">
            <Award className="w-8 h-8 text-emerald-400" />
            <h3 className="text-base font-bold text-white">Continuous Parent Updates</h3>
            <p className="text-xs leading-relaxed">
              Weekly progress reports, attendance alerts, and transparent fee management.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
