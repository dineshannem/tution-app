import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  GraduationCap,
  Sparkles,
  BookOpen,
  Users,
  Award,
  Calendar,
  CheckCircle2,
  Video,
  FileText,
  MessageSquare,
  ChevronDown,
  Star,
  MapPin,
  Phone,
  Mail,
  Send,
  HelpCircle
} from 'lucide-react';

interface PublicHomeProps {
  setActiveTab: (tab: string) => void;
  openFreeDemo: () => void;
  openAdmission: () => void;
  onSuccessToast: (msg: string) => void;
}

export const PublicHome: React.FC<PublicHomeProps> = ({
  setActiveTab,
  openFreeDemo,
  openAdmission,
  onSuccessToast
}) => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [contactForm, setContactForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const [submittingContact, setSubmittingContact] = useState(false);

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittingContact(true);
    try {
      await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(contactForm)
      });
      setSubmittingContact(false);
      setContactForm({ name: '', email: '', phone: '', subject: '', message: '' });
      onSuccessToast("Thank you for contacting KKR Tuition! We will get back to you soon.");
    } catch (err) {
      setSubmittingContact(false);
      onSuccessToast("Message sent successfully!");
    }
  };

  const subjectsList = [
    { name: 'Mathematics', desc: 'Step-by-step problem solving, shortcut formulas, board exam preparation.', icon: '📐' },
    { name: 'Science', desc: 'Physics numericals, Chemistry balancing equations & Biology diagrams.', icon: '🔬' },
    { name: 'Social Science', desc: 'History timelines, Geography maps, Civics & Economics breakdown.', icon: '🌍' },
    { name: 'English', desc: 'Grammar mastery, unseen passage techniques, literature & essay writing.', icon: '📚' },
    { name: 'Hindi', desc: 'Vyakaran, Patra Lekhan, comprehension and literature care.', icon: '✍️' },
    { name: 'Telugu', desc: 'Telugu Vyakanam, Sandhulu, Samasalu & Board preparation.', icon: '🪶' },
    { name: 'Computer Science', desc: 'Basic programming concepts, MS Office, logic building.', icon: '💻' }
  ];

  const faqs = [
    {
      q: 'Why single-teacher tuition instead of multiple unknown tutors?',
      a: 'With KKR Sir taking all core batches, every student receives consistent academic methodology, personal accountability, and single-point responsibility without teacher turnover or dilution of quality.'
    },
    {
      q: 'How are small batches beneficial for weak students?',
      a: 'Batches are strictly capped at 15 students. This allows KKR Sir to identify individual weak points, ask direct questions during class, and provide Telugu & English explanation whenever required.'
    },
    {
      q: 'Are weekly test marks shared with parents?',
      a: 'Yes! Marks are uploaded to our online Parent Portal and sent via WhatsApp updates after every weekly evaluation.'
    },
    {
      q: 'What is the format for online classes?',
      a: 'Online classes are conducted live on Google Meet with interactive screen sharing, followed by uploaded recorded sessions for anytime revision.'
    },
    {
      q: 'How does daily homework checking work?',
      a: 'Students submit homework physically in offline batches or upload PDFs through the Student Portal. KKR Sir evaluates and provides written remarks and marks.'
    }
  ];

  return (
    <div className="space-y-20 pb-16">
      {/* 1. Hero Banner Section */}
      <section className="relative overflow-hidden bg-slate-950/70 text-white pt-12 pb-20 rounded-3xl mx-4 sm:mx-6 lg:mx-8 mt-4 shadow-2xl border border-white/10 backdrop-blur-2xl">
        <div className="absolute inset-0 bg-gradient-to-tr from-indigo-950/80 via-slate-900/90 to-purple-950/80 opacity-90" />
        <div className="absolute -top-32 -right-32 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 bg-amber-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-bold tracking-wide shadow-sm">
              <Sparkles className="w-4 h-4 text-amber-400" /> ADMISSIONS OPEN FOR ACADEMIC YEAR 2026-27
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight leading-tight">
              Empowering Students for Board Excellence in <span className="bg-gradient-to-r from-amber-300 via-amber-200 to-orange-300 bg-clip-text text-transparent">Classes 1 to 10</span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 max-w-2xl leading-relaxed">
              KKR Tuition offers dedicated single-teacher instruction for CBSE & State Board students. Small batches, daily homework, weekly tests, and explanation in both <span className="text-amber-300 font-semibold">Telugu & English</span> for guaranteed concept clarity.
            </p>

            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                onClick={openFreeDemo}
                className="px-6 py-3.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm shadow-xl shadow-amber-500/25 transition-all flex items-center gap-2 transform hover:-translate-y-0.5"
              >
                <Sparkles className="w-4 h-4" /> Book Free Demo Class
              </button>
              <button
                onClick={openAdmission}
                className="px-6 py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-xl shadow-indigo-600/30 transition-all border border-indigo-400/30 flex items-center gap-2 transform hover:-translate-y-0.5"
              >
                <GraduationCap className="w-4 h-4" /> Apply Online Admission
              </button>
            </div>

            {/* Quick Metrics */}
            <div className="grid grid-cols-3 gap-4 pt-6 border-t border-white/10 text-center lg:text-left">
              <div>
                <div className="text-2xl font-black text-amber-300">15+ Yrs</div>
                <div className="text-xs text-slate-400">Teaching Experience</div>
              </div>
              <div>
                <div className="text-2xl font-black text-indigo-300">Max 15</div>
                <div className="text-xs text-slate-400">Students Per Batch</div>
              </div>
              <div>
                <div className="text-2xl font-black text-emerald-400">98%</div>
                <div className="text-xs text-slate-400">Board Pass Rate</div>
              </div>
            </div>
          </div>

          {/* Hero Visual Card */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-full max-w-md bg-white/5 backdrop-blur-xl border border-white/15 rounded-3xl p-6 shadow-2xl space-y-4">
              <div className="relative rounded-2xl overflow-hidden h-52">
                <img
                  src="https://images.unsplash.com/photo-1580582932707-520aed937b7b?w=800&auto=format&fit=crop&q=80"
                  alt="KKR Tuition Classroom"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
                <span className="absolute bottom-3 left-3 bg-amber-500 text-slate-950 text-xs font-extrabold px-3 py-1 rounded-lg shadow-md">
                  Owner-Teacher KKR Sir
                </span>
              </div>

              <div className="space-y-2 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>Classes 1–10 (CBSE & State Board)</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>Special Care for Weak & Shy Students</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>Weekly Tests & Instant Parent WhatsApp Updates</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                  <span>Online Google Meet + Offline Classroom Batches</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Why Choose KKR Tuition */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        <div className="text-center space-y-3 max-w-3xl mx-auto">
          <span className="text-xs font-bold text-amber-300 uppercase tracking-widest bg-amber-500/10 px-3.5 py-1 rounded-full border border-amber-500/20">
            Unmatched Quality
          </span>
          <h2 className="text-3xl font-extrabold text-white">
            Why Parents & Students Choose KKR Tuition
          </h2>
          <p className="text-sm text-slate-300">
            We focus strictly on concept depth, small batch size, and continuous evaluation so every child achieves top marks in school and board exams.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white/5 backdrop-blur-xl p-6 rounded-2xl border border-white/10 shadow-xl hover:border-amber-500/40 transition-all space-y-3">
            <div className="w-12 h-12 rounded-xl bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Small Batches (Max 15)</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              No overcrowded hall of 100 students. Small batch size guarantees personal attention from KKR Sir for every single student.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl p-6 rounded-2xl border border-white/10 shadow-xl hover:border-indigo-500/40 transition-all space-y-3">
            <div className="w-12 h-12 rounded-xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 flex items-center justify-center">
              <BookOpen className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Telugu & English Medium</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Concepts explained step-by-step in clear Telugu and English so students grasp fundamental logic without hesitation.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl p-6 rounded-2xl border border-white/10 shadow-xl hover:border-purple-500/40 transition-all space-y-3">
            <div className="w-12 h-12 rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30 flex items-center justify-center">
              <FileText className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Daily Homework & Weekly Tests</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Daily practice problems evaluated with teacher remarks. Rigorous weekly tests simulate real exam conditions.
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl p-6 rounded-2xl border border-white/10 shadow-xl hover:border-emerald-500/40 transition-all space-y-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center justify-center">
              <MessageSquare className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-white">Parent Progress Updates</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              Parents get direct access to child attendance, weekly marks, and instant teacher messages via the Parent Portal.
            </p>
          </div>
        </div>
      </section>

      {/* 3. Subjects Taught */}
      <section className="bg-slate-950/40 py-16 border-y border-white/10 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
          <div className="text-center space-y-3 max-w-2xl mx-auto">
            <h2 className="text-3xl font-extrabold text-white">Subjects Taught (Classes 1–10)</h2>
            <p className="text-sm text-slate-300">
              Comprehensive syllabus coverage aligned with CBSE and Telangana State Board guidelines.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {subjectsList.map((sub, i) => (
              <div
                key={i}
                className="bg-white/5 backdrop-blur-xl p-6 rounded-2xl border border-white/10 shadow-xl hover:border-indigo-400/50 transition-all flex items-start gap-4"
              >
                <div className="text-3xl p-3 bg-white/10 rounded-2xl flex-shrink-0 border border-white/10">{sub.icon}</div>
                <div>
                  <h3 className="text-base font-bold text-white">{sub.name}</h3>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">{sub.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Teaching Methodology & Special Care */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div className="space-y-6">
          <span className="text-xs font-bold text-indigo-300 uppercase tracking-widest bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20">
            Single Teacher Dedication
          </span>
          <h2 className="text-3xl font-extrabold text-white">
            Special Care for Weak & Shy Students
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Every child learns at their own pace. KKR Sir personally identifies students needing extra help in Mathematics, Science formulas, or language grammar and provides custom guidance before or after batch hours.
          </p>

          <div className="space-y-3">
            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xl">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-white">Zero-Fear Classroom Culture</h4>
                <p className="text-xs text-slate-400">Students are encouraged to ask doubt questions freely without feeling self-conscious.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xl">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-white">Offline & Online Google Meet Flexibility</h4>
                <p className="text-xs text-slate-400">Attend in-person at our Hyderabad tuition center or join live Google Meet classes remotely.</p>
              </div>
            </div>

            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-xl">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-bold text-white">Curated PDF Notes & Formulas</h4>
                <p className="text-xs text-slate-400">Handcrafted formula sheets, ray diagram guides, and previous 10-year board paper solutions.</p>
              </div>
            </div>
          </div>
        </div>

        <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-white/15 h-96">
          <img
            src="https://images.unsplash.com/photo-1577896851231-70ef18881754?w=800&auto=format&fit=crop&q=80"
            alt="Teaching Care"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent flex items-end p-6">
            <div className="text-white space-y-1">
              <div className="text-xs font-bold text-amber-300 uppercase tracking-widest">KKR Tuition Learning Center</div>
              <div className="text-lg font-bold">Small Batches • High Success • Personal Care</div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Student Success Stories & Testimonials */}
      <section className="bg-slate-950/60 text-white py-16 border-y border-white/10 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
          <div className="text-center space-y-3 max-w-2xl mx-auto">
            <span className="text-xs font-bold text-amber-300 uppercase tracking-widest">Proven Track Record</span>
            <h2 className="text-3xl font-extrabold">What Parents & Students Say</h2>
            <p className="text-xs text-slate-400">Real feedback from parents of CBSE & Telangana State Board toppers.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white/5 border border-white/10 p-6 rounded-2xl space-y-4 backdrop-blur-xl shadow-xl">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-400" />)}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-normal">
                "KKR Sir's personal attention changed my daughter's score from 65% to 92% in Maths! The small batch size and daily homework checking really make a difference."
              </p>
              <div className="flex items-center gap-3 pt-2 border-t border-white/10">
                <img src="https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150" alt="Parent" className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/40" />
                <div>
                  <h4 className="text-xs font-bold text-white">Srinivas Reddy</h4>
                  <p className="text-[11px] text-amber-300">Parent of Ananya (Class 10 State)</p>
                </div>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 p-6 rounded-2xl space-y-4 backdrop-blur-xl shadow-xl">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-400" />)}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-normal">
                "KKR Sir explains complex Physics numerics and Maths formulas in very simple Telugu and English. Weekly tests prepared me completely for the board exam!"
              </p>
              <div className="flex items-center gap-3 pt-2 border-t border-white/10">
                <img src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150" alt="Student" className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/40" />
                <div>
                  <h4 className="text-xs font-bold text-white">Rahul Sharma</h4>
                  <p className="text-[11px] text-amber-300">Student (Class 10 CBSE - 94% Scored)</p>
                </div>
              </div>
            </div>

            <div className="bg-white/5 border border-white/10 p-6 rounded-2xl space-y-4 backdrop-blur-xl shadow-xl">
              <div className="flex items-center gap-1 text-amber-400">
                {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-amber-400" />)}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed font-normal">
                "Parent updates on WhatsApp and online portal keep us informed every week. Best tuition in Hyderabad for CBSE and State Board!"
              </p>
              <div className="flex items-center gap-3 pt-2 border-t border-white/10">
                <img src="https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150" alt="Parent" className="w-10 h-10 rounded-full object-cover ring-2 ring-indigo-500/40" />
                <div>
                  <h4 className="text-xs font-bold text-white">Lakshmi Devi</h4>
                  <p className="text-[11px] text-amber-300">Parent of Sai Karthik (Class 9 CBSE)</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 6. FAQ Accordion */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-2">
          <span className="text-xs font-bold text-indigo-300 uppercase tracking-widest bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20">Got Questions?</span>
          <h2 className="text-3xl font-extrabold text-white">Frequently Asked Questions</h2>
        </div>

        <div className="space-y-3">
          {faqs.map((faq, idx) => (
            <div
              key={idx}
              className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 overflow-hidden shadow-lg"
            >
              <button
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                className="w-full text-left p-4 sm:p-5 flex items-center justify-between font-bold text-sm text-white hover:bg-white/5 transition-colors"
              >
                <span className="flex items-center gap-2">
                  <HelpCircle className="w-4 h-4 text-indigo-300 flex-shrink-0" />
                  {faq.q}
                </span>
                <ChevronDown className={`w-5 h-5 transition-transform ${openFaq === idx ? 'rotate-180' : ''}`} />
              </button>

              {openFaq === idx && (
                <div className="px-5 pb-5 pt-1 text-xs text-slate-300 border-t border-white/10 leading-relaxed">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* 7. Contact Form & Google Map */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        <div className="lg:col-span-6 bg-white/5 backdrop-blur-2xl p-8 rounded-3xl border border-white/10 shadow-2xl space-y-6">
          <div>
            <span className="text-xs font-bold text-amber-300 uppercase tracking-wider">Get In Touch</span>
            <h3 className="text-2xl font-extrabold text-white mt-1">Send an Enquiry to KKR Sir</h3>
            <p className="text-xs text-slate-400 mt-1">Have questions about batch schedules or fees? Write to us directly.</p>
          </div>

          <form onSubmit={handleContactSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-300 mb-1 block">Your Name *</label>
                <input
                  type="text"
                  required
                  placeholder="Full Name"
                  value={contactForm.name}
                  onChange={e => setContactForm({ ...contactForm, name: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-white/5 text-white placeholder-slate-400 text-xs focus:ring-2 focus:ring-indigo-500 focus:bg-white/10 outline-none backdrop-blur-md"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-300 mb-1 block">Mobile Number *</label>
                <input
                  type="tel"
                  required
                  placeholder="+91 98765 43210"
                  value={contactForm.phone}
                  onChange={e => setContactForm({ ...contactForm, phone: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-white/5 text-white placeholder-slate-400 text-xs focus:ring-2 focus:ring-indigo-500 focus:bg-white/10 outline-none backdrop-blur-md"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-300 mb-1 block">Email Address</label>
                <input
                  type="email"
                  placeholder="name@gmail.com"
                  value={contactForm.email}
                  onChange={e => setContactForm({ ...contactForm, email: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-white/5 text-white placeholder-slate-400 text-xs focus:ring-2 focus:ring-indigo-500 focus:bg-white/10 outline-none backdrop-blur-md"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-slate-300 mb-1 block">Subject</label>
                <input
                  type="text"
                  placeholder="Class 10 CBSE Batch Timings"
                  value={contactForm.subject}
                  onChange={e => setContactForm({ ...contactForm, subject: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-white/5 text-white placeholder-slate-400 text-xs focus:ring-2 focus:ring-indigo-500 focus:bg-white/10 outline-none backdrop-blur-md"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-slate-300 mb-1 block">Your Message *</label>
              <textarea
                rows={4}
                required
                placeholder="Ask any details regarding tuition timings, fee structure, or Telugu explanation care..."
                value={contactForm.message}
                onChange={e => setContactForm({ ...contactForm, message: e.target.value })}
                className="w-full px-3.5 py-2.5 rounded-xl border border-white/10 bg-white/5 text-white placeholder-slate-400 text-xs focus:ring-2 focus:ring-indigo-500 focus:bg-white/10 outline-none backdrop-blur-md"
              />
            </div>

            <button
              type="submit"
              disabled={submittingContact}
              className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-500/25 border border-indigo-400/30 transition-all flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" /> Send Message
            </button>
          </form>
        </div>

        {/* Contact Info & Map Card */}
        <div className="lg:col-span-6 space-y-6">
          <div className="bg-white/5 backdrop-blur-2xl text-white p-8 rounded-3xl space-y-6 shadow-2xl border border-white/10">
            <h3 className="text-xl font-bold">Center Details & Working Hours</h3>
            <div className="space-y-4 text-xs text-slate-300">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-amber-300 flex-shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold text-white block text-sm">KKR Tuition Learning Center</span>
                  <span>H.No 4-12, Main Road, Near Bus Stop, Hyderabad, Telangana 500038</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <div>
                  <span className="font-bold text-white block text-sm">Direct Teacher Contact</span>
                  <span>+91 98765 43210 / +91 91234 56789</span>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-indigo-300 flex-shrink-0" />
                <div>
                  <span className="font-bold text-white block text-sm">Email Support</span>
                  <span>teacher@kkrtuition.com</span>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Google Map Mock Card */}
          <div className="rounded-3xl border border-white/10 overflow-hidden shadow-xl h-64 bg-slate-900 relative flex items-center justify-center p-6 text-center">
            <div className="absolute inset-0 bg-cover bg-center opacity-30" style={{ backgroundImage: "url('https://images.unsplash.com/photo-1526778548025-fa2f459cd5c1?w=800&auto=format&fit=crop&q=80')" }} />
            <div className="relative z-10 space-y-3 bg-slate-950/80 backdrop-blur-xl p-6 rounded-2xl border border-white/15 shadow-2xl">
              <MapPin className="w-8 h-8 text-rose-500 mx-auto animate-bounce" />
              <h4 className="text-sm font-bold text-white">KKR Tuition Hyderabad Center</h4>
              <p className="text-xs text-slate-300">Convenient location with safe environment & parking.</p>
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noreferrer"
                className="inline-block text-xs font-bold bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl transition-all shadow-lg border border-indigo-400/30"
              >
                Open Google Maps Navigation
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
