import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { UserRole } from '../../types';
import {
  GraduationCap,
  Bell,
  Sun,
  Moon,
  Monitor,
  LogOut,
  UserCheck,
  PhoneCall,
  Calendar,
  Sparkles,
  Menu,
  X,
  ChevronDown,
  KeyRound,
  LogIn,
  ShieldAlert,
  BookOpen,
  Award,
  Video,
  Users
} from 'lucide-react';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  openFreeDemo: () => void;
  openAdmission: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  openFreeDemo,
  openAdmission
}) => {
  const { user, role, switchRole, logout } = useAuth();
  const { themeMode, setThemeMode, resolvedTheme } = useTheme();
  const [showThemeMenu, setShowThemeMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [notifications, setNotifications] = useState<any[]>([]);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest('.theme-dropdown-container')) {
        setShowThemeMenu(false);
      }
      if (!target.closest('.notification-dropdown-container')) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    fetch('/api/notifications')
      .then(r => r.json())
      .then(data => setNotifications(data))
      .catch(err => console.error(err));
  }, []);

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const publicNavItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About KKR Sir' },
    { id: 'courses', label: 'Courses & Classes' },
    { id: 'subjects', label: 'Subjects' },
    { id: 'faculty', label: 'Faculty' },
    { id: 'gallery', label: 'Gallery' },
    { id: 'testimonials', label: 'Reviews' },
    { id: 'contact', label: 'Contact Us' }
  ];

  const teacherNavItems = [
    { id: 't_dashboard', label: 'Dashboard' },
    { id: 't_students', label: 'Students' },
    { id: 't_parents', label: 'Parents' },
    { id: 't_credentials', label: 'Credentials & Reset' },
    { id: 't_batches', label: 'Batches' },
    { id: 't_attendance', label: 'Attendance' },
    { id: 't_homework', label: 'Homework' },
    { id: 't_materials', label: 'Materials' },
    { id: 't_online_classes', label: 'Meet Classes' },
    { id: 't_tests', label: 'Tests & Marks' },
    { id: 't_fees', label: 'Fee Mgmt' },
    { id: 't_gallery', label: 'Gallery Admin' }
  ];

  const studentNavItems = [
    { id: 's_dashboard', label: 'Dashboard' },
    { id: 's_attendance', label: 'Attendance' },
    { id: 's_homework', label: 'Homework' },
    { id: 's_materials', label: 'Study Materials' },
    { id: 's_classes', label: 'Live & Recorded' },
    { id: 's_results', label: 'Results' },
    { id: 's_fees', label: 'Pay Fees' }
  ];

  const parentNavItems = [
    { id: 'p_dashboard', label: 'Dashboard' },
    { id: 'p_attendance', label: 'Child Attendance' },
    { id: 'p_homework', label: 'Homework Track' },
    { id: 'p_results', label: 'Results & Progress' },
    { id: 'p_fees', label: 'Fee Details & Pay' },
    { id: 'p_schedule', label: 'Class Schedule' }
  ];

  const currentNavItems = user
    ? role === 'teacher'
      ? teacherNavItems
      : role === 'student'
      ? studentNavItems
      : role === 'parent'
      ? parentNavItems
      : publicNavItems
    : role === 'guest'
    ? publicNavItems
    : [];

  const mobileDockItems = user
    ? role === 'teacher'
      ? [
          { id: 't_dashboard', label: 'Dashboard', icon: GraduationCap },
          { id: 't_students', label: 'Students', icon: Users },
          { id: 't_attendance', label: 'Attendance', icon: UserCheck },
          { id: 't_homework', label: 'Homework', icon: BookOpen },
          { id: 't_online_classes', label: 'Meets', icon: Calendar },
        ]
      : role === 'student'
      ? [
          { id: 's_dashboard', label: 'Dashboard', icon: GraduationCap },
          { id: 's_attendance', label: 'Attendance', icon: UserCheck },
          { id: 's_homework', label: 'Homework', icon: BookOpen },
          { id: 's_classes', label: 'Classes', icon: Video },
          { id: 's_fees', label: 'Fees', icon: Award },
        ]
      : role === 'parent'
      ? [
          { id: 'p_dashboard', label: 'Dashboard', icon: GraduationCap },
          { id: 'p_attendance', label: 'Attendance', icon: UserCheck },
          { id: 'p_results', label: 'Progress', icon: Award },
          { id: 'p_fees', label: 'Fees', icon: BookOpen },
          { id: 'p_schedule', label: 'Schedule', icon: Calendar },
        ]
      : role === 'guest'
      ? [
          { id: 'home', label: 'Home', icon: GraduationCap },
          { id: 'courses', label: 'Courses', icon: BookOpen },
          { id: 'faculty', label: 'Faculty', icon: Users },
          { id: 'contact', label: 'Contact', icon: PhoneCall },
          { id: 'portal_login', label: 'Login', icon: LogIn },
        ]
      : []
    : role === 'guest'
    ? [
        { id: 'home', label: 'Home', icon: GraduationCap },
        { id: 'courses', label: 'Courses', icon: BookOpen },
        { id: 'faculty', label: 'Faculty', icon: Users },
        { id: 'contact', label: 'Contact', icon: PhoneCall },
        { id: 'portal_login', label: 'Login', icon: LogIn },
      ]
    : [];

  const handlePortalSwitch = (targetRole: UserRole | 'guest', targetTab: string) => {
    if (user && user.role === targetRole) {
      switchRole(targetRole);
      handleTabChange(targetTab);
    } else {
      if (user) {
        logout(); // Force immediate logout when switching to a different portal
      }
      switchRole(targetRole);
      if (targetRole === 'teacher') handleTabChange('teacher_login');
      else if (targetRole === 'parent') handleTabChange('parent_login');
      else if (targetRole === 'student') handleTabChange('student_login');
      else handleTabChange('home');
    }
  };

  const handleDismissNotification = (id: string) => {
    fetch(`/api/notifications/${id}`, { method: 'DELETE' })
      .then(r => r.json())
      .then(data => {
        if (data.notifications) setNotifications(data.notifications);
      })
      .catch(err => console.error(err));
  };

  const handleClearAllNotifications = () => {
    fetch('/api/notifications/clear-all', { method: 'POST' })
      .then(r => r.json())
      .then(data => {
        if (data.notifications) setNotifications(data.notifications);
      })
      .catch(err => console.error(err));
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-950/90 backdrop-blur-2xl border-b border-slate-200 dark:border-white/10 text-slate-900 dark:text-slate-100 transition-colors shadow-sm">
      {/* Role Switcher Top Bar */}
      <div className="bg-slate-900 text-slate-200 text-xs py-1.5 px-4 flex flex-wrap items-center justify-between border-b border-slate-800 backdrop-blur-md">
        <div className="flex items-center gap-2 font-medium">
          <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-400/30 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase tracking-wider">
            KKR Portal Hub
          </span>
          <span className="hidden sm:inline text-slate-300 text-[11px]">
            Switch role to test portals or view public site:
          </span>
        </div>

        <div className="flex items-center gap-1.5 mt-1 sm:mt-0">
          <button
            onClick={() => handlePortalSwitch('guest', 'home')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
              role === 'guest'
                ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30 border border-indigo-400/40 ring-1 ring-indigo-400'
                : 'bg-white/10 text-slate-300 hover:text-white hover:bg-white/20'
            }`}
          >
            Public Site
          </button>
          <button
            onClick={() => handlePortalSwitch('teacher', 't_dashboard')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
              role === 'teacher'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/30 border border-amber-300 ring-1 ring-amber-300'
                : 'bg-white/10 text-slate-300 hover:text-white hover:bg-white/20'
            }`}
          >
            Teacher Control
          </button>
          <button
            onClick={() => handlePortalSwitch('student', 's_dashboard')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
              role === 'student'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30 border border-emerald-300 ring-1 ring-emerald-300'
                : 'bg-white/10 text-slate-300 hover:text-white hover:bg-white/20'
            }`}
          >
            Student Panel
          </button>
          <button
            onClick={() => handlePortalSwitch('parent', 'p_dashboard')}
            className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
              role === 'parent'
                ? 'bg-purple-500 text-white shadow-md shadow-purple-500/30 border border-purple-300 ring-1 ring-purple-300'
                : 'bg-white/10 text-slate-300 hover:text-white hover:bg-white/20'
            }`}
          >
            Parent Panel
          </button>
        </div>
      </div>

      {/* Main Header Container */}
      <div className="w-full mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Top Left Corner Branding + Left-Aligned Menu Items */}
          <div className="flex items-center gap-4 lg:gap-8 flex-1 justify-start overflow-hidden">
            <div
              onClick={() => setActiveTab(role === 'guest' ? 'home' : `${role.charAt(0)}_dashboard`)}
              className="flex items-center gap-2.5 cursor-pointer shrink-0 group"
            >
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-amber-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform border border-white/30">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-lg font-black tracking-tight text-slate-900 dark:text-white">
                    KKR TUITION
                  </span>
                  <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.5 bg-indigo-100 text-indigo-800 dark:bg-indigo-500/20 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-500/30 rounded-md">
                    Classes 1-10
                  </span>
                </div>
                <p className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 -mt-0.5 hidden sm:block">
                  Single Teacher Excellence • K. K. Rao
                </p>
              </div>
            </div>

            {/* Desktop Navigation Links - Anchored Left beside Brand Logo */}
            <nav className="hidden lg:flex items-center gap-1 overflow-x-auto py-1 scrollbar-none">
              {currentNavItems.map(item => {
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleTabChange(item.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-extrabold whitespace-nowrap transition-all duration-200 relative ${
                      isActive
                        ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/20 dark:bg-indigo-500 dark:text-white'
                        : 'text-slate-700 hover:text-indigo-700 hover:bg-slate-100 dark:text-slate-200 dark:hover:text-white dark:hover:bg-white/10'
                    }`}
                  >
                    {item.label}
                    {isActive && (
                      <motion.div
                        layoutId="activeTabBadge"
                        className="absolute inset-0 bg-indigo-600 dark:bg-indigo-500 rounded-xl -z-10"
                        transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                      />
                    )}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Action CTAs & Controls */}
          <div className="flex items-center gap-2 shrink-0">
            {role === 'guest' ? (
              <div className="hidden sm:flex items-center gap-2">
                <button
                  onClick={openFreeDemo}
                  className="px-3 py-1.5 rounded-xl text-xs font-extrabold text-amber-900 bg-amber-100 border border-amber-300 hover:bg-amber-200 dark:text-amber-300 dark:bg-amber-500/20 dark:border-amber-500/30 transition-all flex items-center gap-1.5 shadow-sm"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" /> Free Demo
                </button>
                <button
                  onClick={openAdmission}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-extrabold text-white bg-indigo-600 hover:bg-indigo-700 border border-indigo-500 shadow-md transition-all"
                >
                  Apply Admission
                </button>
              </div>
            ) : null}

            {/* Notifications Dropdown */}
            {role !== 'guest' && user && (
              <div className="relative notification-dropdown-container">
                <button
                  onClick={() => setShowNotifications(!showNotifications)}
                  className="p-2 rounded-xl text-slate-800 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 transition-colors relative"
                  title="View alerts & notifications"
                >
                  <Bell className="w-4 h-4" />
                  {notifications.length > 0 && (
                    <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-rose-500 rounded-full ring-2 ring-white dark:ring-slate-900" />
                  )}
                </button>

                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 py-3 z-50">
                    <div className="px-4 pb-2 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-extrabold text-slate-900 dark:text-white uppercase tracking-wider">
                          Alerts & Notifications
                        </h4>
                        <span className="text-[10px] bg-indigo-100 text-indigo-800 dark:bg-indigo-500/20 dark:text-indigo-300 px-2 py-0.5 rounded-full font-bold">
                          {notifications.length} Active
                        </span>
                      </div>
                      {notifications.length > 0 && (
                        <button
                          onClick={handleClearAllNotifications}
                          className="text-[10px] font-bold text-rose-600 dark:text-rose-400 hover:underline"
                        >
                          Clear All
                        </button>
                      )}
                    </div>

                    <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800">
                      {notifications.length === 0 ? (
                        <div className="p-6 text-center text-xs text-slate-500 dark:text-slate-400">
                          No active notifications at the moment.
                        </div>
                      ) : (
                        notifications.map(n => (
                          <div key={n.id} className="p-3 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors flex items-start justify-between gap-2">
                            <div>
                              <p className="text-xs font-bold text-slate-900 dark:text-white">{n.title}</p>
                              <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5 leading-snug">{n.message}</p>
                              <span className="text-[10px] text-slate-400 mt-1 block font-medium">{n.createdAt}</span>
                            </div>
                            <button
                              onClick={() => handleDismissNotification(n.id)}
                              className="text-slate-400 hover:text-rose-500 p-1"
                              title="Dismiss notification"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Theme Mode Selector (Light, Dark, System) */}
            <div className="relative theme-dropdown-container">
              <button
                onClick={() => setShowThemeMenu(!showThemeMenu)}
                className="p-2 rounded-xl text-slate-800 hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10 transition-colors flex items-center gap-1"
                title={`Theme: ${themeMode} (${resolvedTheme})`}
              >
                {themeMode === 'system' ? (
                  <Monitor className="w-4 h-4 text-indigo-500" />
                ) : resolvedTheme === 'dark' ? (
                  <Moon className="w-4 h-4 text-amber-400" />
                ) : (
                  <Sun className="w-4 h-4 text-amber-500" />
                )}
              </button>

              {showThemeMenu && (
                <div className="absolute right-0 mt-2 w-40 bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 py-1.5 z-50">
                  <button
                    onClick={() => { setThemeMode('light'); setShowThemeMenu(false); }}
                    className={`w-full px-3.5 py-2 text-xs font-bold flex items-center gap-2 transition-colors ${
                      themeMode === 'light'
                        ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                    }`}
                  >
                    <Sun className="w-4 h-4 text-amber-500" /> Light Mode
                  </button>
                  <button
                    onClick={() => { setThemeMode('dark'); setShowThemeMenu(false); }}
                    className={`w-full px-3.5 py-2 text-xs font-bold flex items-center gap-2 transition-colors ${
                      themeMode === 'dark'
                        ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                    }`}
                  >
                    <Moon className="w-4 h-4 text-indigo-400" /> Dark Mode
                  </button>
                  <button
                    onClick={() => { setThemeMode('system'); setShowThemeMenu(false); }}
                    className={`w-full px-3.5 py-2 text-xs font-bold flex items-center gap-2 transition-colors ${
                      themeMode === 'system'
                        ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/40'
                        : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5'
                    }`}
                  >
                    <Monitor className="w-4 h-4 text-slate-500" /> System Default
                  </button>
                </div>
              )}
            </div>

            {/* User Profile Badge or Login */}
            {user ? (
              <div className="flex items-center gap-3 pl-3 border-l border-slate-200 dark:border-white/10">
                <div className="flex items-center gap-2">
                  <img
                    src={user.avatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150'}
                    alt={user.name}
                    className="w-8 h-8 rounded-full object-cover ring-2 ring-indigo-500 shadow-sm"
                  />
                  <div className="hidden md:block text-left">
                    <div className="text-xs font-bold text-slate-900 dark:text-white leading-tight">{user.name}</div>
                    <div className="text-[10px] text-indigo-600 dark:text-indigo-300 font-extrabold capitalize">{user.role}</div>
                  </div>
                </div>
                <button
                  onClick={logout}
                  className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-rose-600 via-red-600 to-pink-600 hover:from-rose-700 hover:to-pink-700 text-white font-black text-xs shadow-lg shadow-rose-600/25 border border-rose-400/40 flex items-center gap-1.5 transition-all duration-200 hover:scale-105 active:scale-95 cursor-pointer"
                  title="Logout of current session"
                >
                  <LogOut className="w-3.5 h-3.5 text-rose-100" />
                  <span className="hidden sm:inline tracking-wider uppercase text-[10px]">Logout</span>
                </button>
              </div>
            ) : (
              <button
                onClick={() => handleTabChange('portal_login')}
                className="px-3.5 py-1.5 rounded-xl text-xs font-extrabold text-white bg-indigo-600 hover:bg-indigo-700 shadow-md transition-all flex items-center gap-1.5"
              >
                <LogIn className="w-4 h-4" /> Portal Login
              </button>
            )}

            {/* Mobile menu trigger */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/10 border border-slate-200 dark:border-white/10"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden border-t border-slate-200 dark:border-white/10 bg-white dark:bg-slate-900 px-4 py-3 space-y-1 shadow-xl"
          >
            {currentNavItems.map(item => (
              <button
                key={item.id}
                onClick={() => {
                  handleTabChange(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full text-left px-3 py-2 rounded-xl text-xs font-extrabold transition-all ${
                  activeTab === item.id
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'text-slate-800 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-white/5'
                }`}
              >
                {item.label}
              </button>
            ))}
            <div className="pt-3 border-t border-slate-200 dark:border-white/10 flex flex-col gap-2">
              {!user && (
                <button
                  onClick={() => { handleTabChange('portal_login'); setMobileMenuOpen(false); }}
                  className="w-full py-2 bg-indigo-600 text-white rounded-xl text-xs font-extrabold shadow flex items-center justify-center gap-1.5"
                >
                  <LogIn className="w-4 h-4" /> Open Portal Login Page
                </button>
              )}
              <button
                onClick={() => { openFreeDemo(); setMobileMenuOpen(false); }}
                className="w-full py-2 bg-amber-100 text-amber-900 border border-amber-300 rounded-xl text-xs font-extrabold"
              >
                Book Free Demo Class
              </button>
              <button
                onClick={() => { openAdmission(); setMobileMenuOpen(false); }}
                className="w-full py-2 bg-indigo-600 text-white rounded-xl text-xs font-extrabold shadow"
              >
                Apply Online Admission
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Glass Mobile Bottom Navigation Dock */}
      {mobileDockItems.length > 0 && (
        <nav className="lg:hidden fixed bottom-3 left-3 right-3 z-50 bg-white/90 dark:bg-slate-900/90 backdrop-blur-2xl border border-slate-200/90 dark:border-white/10 rounded-2xl shadow-2xl px-2 py-1.5 flex items-center justify-around">
          {mobileDockItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleTabChange(item.id)}
                className={`flex flex-col items-center gap-0.5 px-2.5 py-1 rounded-xl transition-all relative ${
                  isActive
                    ? 'text-indigo-600 dark:text-indigo-400 font-extrabold'
                    : 'text-slate-500 dark:text-slate-400 font-medium hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className={`w-5 h-5 transition-transform duration-200 ${isActive ? 'scale-110' : ''}`} />
                <span className="text-[10px] tracking-tight">{item.label}</span>
                {isActive && (
                  <motion.div
                    layoutId="activeDockDot"
                    className="absolute -bottom-0.5 w-1 h-1 bg-indigo-600 dark:bg-indigo-400 rounded-full"
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
        </nav>
      )}
    </header>
  );
};

